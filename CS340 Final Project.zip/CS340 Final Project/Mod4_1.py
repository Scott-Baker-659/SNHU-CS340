from pymongo import MongoCLient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal Collection in MongoDB """"
    
    def _init_(self):
        # Initializing the MongoClient.
        # This helps to access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:37572' % (username, password))
        self.database = self.client['project']
        
# Create method for C in CRUD

    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) # data should be dictionary
            
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            
# Read Method for R in CRUD
    
    def read (self, searchData);
    if searchData:
        data = self.database.animals.find(searchData, {"_id": False})
    else:
        data = self.datbase.animals.find({}, {"_id": false})
        #return dataset or let the error flow up
        return data
    
# Update method for U in CRUD

    def update(self, searchData, updateData):
        if searchData is not None:
            result = self.database.animals.update_many(searchData, {"$set": updateData})
        else:
            return "{}"
        return result.raw_result
    
#Delete method for D in CRUD

    def delete(self, deleteData):
        if deleteData is not None:
            result = self.database.animals.delete_many(deleteData)
        else:
            return"{}"
        return result.raw_result
    
    
    